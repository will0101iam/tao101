---
title: "扣子coze 的假 agent skills（技能商店）"
date: "2026-01-19"
status: "published"
author: "Guotao Tao"
source_url: "https://mp.weixin.qq.com/s/G31AcSj3ukkYXVJheM9_gg"
cover_image: ""
id: "5b858531-4eaa-4176-8cf6-886ff394993d"
slug: "扣子coze-的假-agent-skills技能商店"
export_index: 5
---

# 扣子coze 的假 agent skills（技能商店）

> the illusion of agent skills

今天被动的刷到好多吹嘘 coze skills 的商单帖子，从头拉到底，我硬是没看到skills 在哪里，怎么skills 还要用户像笨蛋一样一个一个手动的@出来啊，这是又回到了 2023 年吗，@GPTs 吗，哥们我是不是穿越到 2023 年了呀😄，怎么和我在 claude code 和 opencode 里面用的 skills 不一样啊，到底是我用的方式方法不对，还是我没掌握到 coze 产品经理的深厚功底和产品精髓，好难猜呀🤣

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAYWcgWGcERfibmicKWYKibBa2U1165uFVxNd7aCPuphvDOAcq9Vp5bibCWf6RIb67iceXib7yWsIibLX3Qtw/640?wx_fmt=png&from=appmsg)

01

Skills内部是啥？

skills 说白了就是 prompt，一个封装好的能够 100% 掌握用户某个需求的高质量 prompt，就像是

一本使用手册

，里面的东西能够高质量的完成用户的需求。

1. 比如一个能够生成【动态特效的 ppt】 skills，他就是一本教 LLM 如何高质量的生成【动态特效 ppt】的方式方法，里面包含了执行流程、细节要求等 prompt；
2. 再比如我想要在我的产品里面接入stripe支付，我发现 skills 市场有一个这样的 skills，我就拿来用，里面有一步一步指导 LLM 如何将 stripe 内嵌到我的产品中的全流程详细操作手册，我只需要在对话中提供我stripe 的钱包密钥、id 等收付款信息，就可以等着我的产品接入 stripe 收款方式了。

看到了吧，这是 skills 内部封装的东西，你可以把它看成一个 tools，能够指挥 LLM 更好的干专业的活的工具，你也可以把它看成是一段高质量的、专业对口的封装好的 prompt，干什么活用什么 skills，本质其实就是 prompt，当然再往下本质都是文本哈哈。

02

Skills是如何被LLM调用的？

说清楚了 skills 内部是个什么东西，我们来说说 skills 是怎么被使用的，在各种 IDE 编辑器里面，

1. 是不是把各种 skills 都写在 skills.md这个文件里面？
2. 是不是按需触发/自动触发，当你提出一个任务（例如“修复登录页面的样式错误”）时，Claude 会自动判断需要哪些“技能”，它会先列出目录，读取相关 CSS 文件，修改代码，最后甚至可能运行测试命令——这一切都是它自主决定调用的？
3. 是不是可以通过 mcp 链接 skillsmp 等各种 skills 市场，寻找到最能完成用户需求的 skills，弄下来安装下来用？
4. 难道你还要用户去自己安装过的各种 skills 里面翻吗，还是你需要在对话框里面@一下这个 skills，但你别说，coze 就是这样，就是用这个勇气、有这个巧思哈，在天下后的位置上敢为天下先，他竟然要用户@，不管是考虑到国内用户的交互习惯还是架构设计、技术实现、权限管理上，都没必要拉出这个老东西@，不知道产品经理又是看了哪个竞品获得的灵感呢，不过 coze 从娘胎里出来就奠定了这个主基调，早期版本甚至连 Dify 里写错的英文都一模一样搬运。

03

出地铁语音输入的口水话

coze的skills上来有什么用啊，跟之前的智能体agent这种提示词，这种GPTS有什么差别啊，都是你要人工去@@@的，他也不会自己帮你去寻找。Cloud code里面的skills，核心的部分是他能够自己去按照你的skills.MD这个文件，在里面自己去寻找完成用户需求最适配的skills。你现在没有这个能力，就是假的skills,说到底就是 prompt，缺少了自主寻找的能力就是挂羊头卖狗肉的 skills。
