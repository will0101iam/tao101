---
title: "拆解 Manus：MCP 与 Deep Research 的高耦合利用"
date: "2025-03-05"
status: "published"
author: "Guotao Tao"
source_url: "https://mp.weixin.qq.com/s/oCG-PwGtR4MHOf3Nuw2FXw"
cover_image: ""
id: "d5e81602-66d3-4b35-b1d6-2419fbbcdaa2"
slug: "拆解-manusmcp-与-deep-research-的高耦合利用"
export_index: 8
---

# 拆解 Manus：MCP 与 Deep Research 的高耦合利用

> tight coupling in deep research

昨晚我刷到了 Manus，让我感到惊艳，很久没有一款产品能唤醒我的惊奇和好奇心。

看到这款产品，看了他提供的 usecase，有些东西我感到太熟悉了，我尝试通俗易懂的拆解Manus 背后的技术实现和原理。

Manus 是一款 Agent 产品，就像官方所说的“Leave it to Manus”，把一切都交给 Manus，他什么都能做，全自动的 Agent，无需人为干涉和纠偏，一气呵成给你最好的结果，可能是动画，可能是各类可视化的图表，可能是一份详细的研报 PPT，他是一个通用的 AI 代理，可以连接思想和行动：它不仅会思考，还会提供结果。Manus 擅长工作和生活中的各种任务，在休息时完成所有事情。

Manus，源自拉丁语中的“手”，是一个通用的 AI 代理，可将您的想法转化为行动。

本文目录

1. Agent Base
2. MCP 协议
3. Deep Research

## **01**

**Agent Base**

Agent 我相信大家都已经听烂了，一个说烂了的名词，但有时候真绕不过去。如果一个人说到 AI，嘴巴上只会一直挂着 Agent、Agent，那我一定会判定他是个吹 b，绣花枕头一包草。

**Agent Base 是什么？**

Manus 的架构上，最明显的是用了 Agent 的那套基��框架，就是拿到用户的一个任务，并不是直接去执行，不是鲁莽的“system 1”，而是使用“system 2”，有思考的去 plan，去拆解用户任务并进行规划，输出一个包含多个子任务的流程目录，规划多少个步骤节点？每一个步骤应该做什么？调用什么工具或信息源去执行子任务？最后将每一个子任务系统性的整合，给用户一个惊艳的视觉输出。

翻出来一张 23 年做的老图：

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAaJKFL4X1XAjjnT96VTCjIN6JLF6zQic5b2K3RswSv842ibnpGL0jMYd0EUZwLZTl4KXEzXqGZ1lcuQ/640?wx_fmt=png&from=appmsg)

Agent 的每一个步骤都是有意识的，有规划的，模型自主的进行任务拆解、规划、执行、反思，完全是一个拟人的状态，人的一般性 sop 可能就是模型认为的人的 know how。

详情可以翻阅之前的关于 Agent 的文章。

#### Manus 中的 Agent Base

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAaJKFL4X1XAjjnT96VTCjINXS2F5icW8hWI9OCmtsxJCN6ZVbt6Wd2AuZzr3KqbDTsNEJMjVxossMA/640?wx_fmt=png&from=appmsg)

像上图中所见，这个示例中，在接收到用户需求后，第一个步骤往往都是拆解，做任务的规划 plan，图中右侧就是 Manus 将用户的需求拆解成了这几十个子任务，分步去完成，完成可以调用各种工具，像这个 usecase 中，就在理解动能守恒知识点的时候，调用了搜索引擎工具，每一个子任务完成都一个就打上【X】。

## **02**

**MCP 协议**

MCP 协议这是个新东西，随着去年 claude 3.5 sonnet-1120 版本的上市一起发布，与此一起发布的还有 computer use，这一个 RPA+AI 视觉的东西，通过多模态的模型识别页面信息，来操纵模拟鼠标点击元素。

#### 什么是 MCP 协议？

模型上下文协议 （MCP） 是一种开放标准，可以帮助 AI 应用程序（尤其是大型语言模型LLMs）与外部数据源和工具连接。

你可能咋一听，这不就是 Agent 吗，对，你说的没错，本质上就是一个 Agent，但是 MCP 他有比 Agent 更高的操作权限。

Agent 的产品一般在 web 网页上，在浏览器里面，他只能通过网络或本地开放的接口，来调用一些比如Google Search、Yahoo Finance这样的搜索、金融api 接口，或者是你部署在本地的 craw4ai 这种爬虫程序。这样的一个 Agent永远被束缚在你的浏览器里面，他不能够拿到你电脑的管控权，他无法拿到管理员权限，他操控不了你的电脑，而有了 MCP 那就不一样了。

MCP 一般需要你将这款 Agent 打包成 client 客户端，安装在你电脑上，就像你是电脑上的飞书客户端、微信客户端那样的形式，这样的一款客户端形式的 Agent，给了他 MCP，那么他就能够接管你的电脑，获得电脑的最高权限，能够操纵你的命令行工具，能够操纵你的浏览器，说白了，有了 MCP 协议的 Agent client 就是你。

#### MCP 在 Cursor 的应用

在 Cursor、Windsurf 等 AI 编程工具中，MCP 是非常有应用场景的。比如你用 Cursor 写了一堆代码，做了一个 web 网页的产品，平常的流程是你从 vscode 上预览你的代码，打开浏览器看，出现了一个报错bug，你复制下来了报错信息，回到 Cursor，粘贴报错信息发送给 Cursor，Cursor 给你原因再修改，你再一次的打开浏览器看看bug解决没有，整个流程太麻烦了，整个一流水线啊我靠。但是有了 MCP 协议的 Cursor，你就不用做这个流水线上打螺丝的工人了，他帮你来做，它自动的预览你的代码，看你的产品，拿到你的报错，自动的去修改，一遍遍的给你 debug，直到没有 bug 为止。

#### MCP 在 Manus

我们把话题再说回来，说回 Manus，我在他提供的“动量守恒教学动画和演示”的 use case 中，发现了“华生”。

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAaJKFL4X1XAjjnT96VTCjINl9jmIL0G8tNxdRouO8oicMOfwWaYwzurp7q9ejmXksKWWM8ibcnKHiaaQ/640?wx_fmt=png&from=appmsg)

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAaJKFL4X1XAjjnT96VTCjINGHI7JRjIPicZxicMXA7PmkrVeqGia0pgdoNRdSEL0jwgYrZY2MIbsXvPw/640?wx_fmt=png&from=appmsg)

我们可以看到图片中，Manus 竟然在操纵浏览器，竟然在点击浏览器中的元素，像人一样滚动滑块，寻找可以点击的信息，他还在使用你的命令行工具来执行命令，创建文件，编辑文件，右侧说他正在使用终端。特别需要注意的是，他操纵的不是你自己的这台电脑的浏览器和命令行工具，而是 Manus 的虚拟机，图片右侧他也说明了“Manus 的电脑”，你可以简单理解为他自己有一台电脑，在他电脑上用他的浏览器和命令行工具，来执行你的需求，给你干活。

1. 图一中，Manus 在操纵浏览器，滚动网页，定位元素找到按钮，再点击元素，这里可能使用的是 playwright 或者类似于 openai operator、claude-computer use 这种多模态识别的技术方案，Manus 这个 Agent 在使用这些技术方案来实现任务。
2. 图二中，Manus 正在执行命令，这一看就是终端命令行命令啊，你想想，平常除了你能用命令行工具，还有谁，还有什么软件能使用终端呢？（排除非法手段哈）

总结一下那么他是怎么在他电脑上来用 Agent 自动化的操纵浏览器和命令行工具呢？

“MCP”

在我们用户面前看Manus 是一个浏览器的网页对吧，背后实际上是 Manus 这个 Agent在他电脑上，基于 MCP 协议下，给你哼哧哼哧干活，透过屏幕，你或许在恍惚之中能够看见 Manus 在他的电脑前正在给你一行一行的敲代码。

## **03**

**Deep Research**

Deep Research 这个东西，在我看来一句话表达，就是基于AI搜索的写作工具。

#### Deep Research 是什么？

Deep Research 是一个拼凑出来的东西，核心是两个。

一个是基于 ai 搜索的 Deep Search，深度搜索，区别于普通的 ai 搜索，深度搜索会在搜索过程中不断的判断搜出来的内容是不是用户想要的，如果不是想要的，那么重组搜索关键词，继续搜索，一层层、一遍遍的挖掘执行搜索，直到搜到匹配的内容为止，当然我们一般都会设置固定的搜索轮数或者 token 耗用限制，不然这个搜索会没完了，不仅拉一下账单要炸，而且用户体验也非常差。

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAaJKFL4X1XAjjnT96VTCjINiacz4C3Z7L103TpebHcnUAE3bRE1fXsGXyAQUSsMeFQm0wJYcDVNiagg/640?wx_fmt=png&from=appmsg)

> 图片来源于 Jina.ai 的文章，写的非常好，深入浅出，大家可以去搜索查阅，也推荐他们家的 Deep Search开源方案。

另一个是和 Agent 一样的一开始要对用户给的任务做规划和拆解，生成一篇目录，然后就开始往每一个目录下面填内容，比如：

用户：我要一份关于留学的报告。

Deep Research会首先生成这样一份目录：

目录：留学报告

1. 留学情况介绍
2. 留学国家
3. 留学学费
4. ……

然后就开始了深度搜索，把第一章节“留学情况介绍”拿去深度搜索，在一轮轮的循环搜索中，将结果返回给你，输出在“留学情况介绍”这个章节下面，第二章节“留学国家”也是同样的手段，最后将所有的目录章节都填好了内容，会用一个长上下文的 LLM 来勘误纠偏，最后就是一份堪堪能用的“Deep Research”。

当然 openai 的Deep Research，绝对没有这么简单，但是主要实现方式就是这样，他一定会做更多的优化和胶水组件来纠正幻觉。

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAaJKFL4X1XAjjnT96VTCjINqQ6ZbLQbK8KibPafexsBHyFTU2t2icL1NVUhE3AuLPG8RsoPoVHkWIrw/640?wx_fmt=png&from=appmsg)

> 上图为 Deep Research 的实现流程，图片来源于 Jina.ai 的文章，写的非常好，深入浅出，大家可以去搜索查阅，也推荐他们家的 Deep Search开源方案。

#### Deep Research 在 Manus 的体现

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAaJKFL4X1XAjjnT96VTCjINeOrIxf7xSrS8yssLx7AaLkzTJwSDpGRlWibHdBMMTdIgib1HvukgBZSQ/640?wx_fmt=png&from=appmsg)

在 Manus 提供的关于分析特斯拉股票的 usecase 中，其实他的结果就是一份 Deep Research，在执行这个任务的过程中，我们也可以看到 Manus 在不断的执行搜索、检查、勘误、反思的过程。

![](https://mmbiz.qpic.cn/mmbiz_svg/oYwP0cFmRU3HwoYqDe9g7Hp2ODOU04UGb1SiaEeCtAYfGWNiaCXN9ZOcAqlV3sYwHYEZ1n4BqlobeiaLPM4ScsXNovUice1iayvqT/640?wx_fmt=svg&from=appmsg)

在 GAIA Benchmark 中，Manus 的 Deep Research能力分别在三个 level 中，都优于了 openai 的 Deep Research，在所有三个难度级别都实现了新的最先进的 （SOTA） 性能。

## **04**

**End**

昨晚十二点左右看到了 Manus，看了官宣视频，看了 usecase，非常棒，我已经很久很久没有看到这样让我惊艳的产品了，我也很久没有写东西了，但 Manus 给我非常强烈的输出欲望，耳目一新。

写了这么多，最后，我想说：

“求个邀请码”

欢迎添加个人微信交流：will0101iam
