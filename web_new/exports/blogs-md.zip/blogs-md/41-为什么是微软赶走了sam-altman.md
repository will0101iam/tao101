---
title: "为什么是微软赶走了Sam Altman？"
date: "2023-11-17"
status: "published"
author: "Guotao Tao"
source_url: "https://mp.weixin.qq.com/s/InLgz6f_oALFy3xGm-l3Kw"
cover_image: ""
id: "e083de74-d26e-4b0a-9313-817ef1e06bd3"
slug: "为什么是微软赶走了sam-altman"
export_index: 41
---

# 为什么是微软赶走了Sam Altman？

> the microsoft power play

![](https://mmbiz.qpic.cn/mmbiz_jpg/Biatd5hKTdAYzvUSXugpa5eD6JntsWJdpnM9SZChR05ORbb7bPbuIHq0szeiarYaWX4GicmoLtiaRLdSBGfHKSvrVg/640?wx_fmt=jpeg&from=appmsg)

今天周六，本想睡个懒觉，一睁眼看看手机现在几点钟，一连串的消息通知让我惊坐起：Opneai的灵魂人物Sam Altman被辞退了。

🤖先抛出我的猜测：微软的意志，奥特曼希望保持openAI的独立发展，微软希望openAI成为自己完全可控的产品。

👿为什么这么猜测？
最近Openai Dev Day发布了Sam排除内部众议而强制主推的GPTs和即将发布的GPTs Store，降低了搭建AI应用的门槛，创建属于Openai的AI应用生态，这本质上在加强Openai&ChatGPT的生态地位，因为这些GPTs都基于Openai提供的底层基础设施，而这个底层往下挖，就会探到Openai做系统OS是必须要做的事情，可以见我之前的文章，并且Sam Altman已经在其投资的AI Pin上试验了，AI Pin自建了其操作系统Cosmos OS。Sam还和前苹果总设计师以及软银孙正义有过多次的接触，有开发AI硬件的趋势，引入孙正义，就直接威胁到了微软这个金主在Openai的地位，这也是微软无法容忍的。

👺真的威胁了吗？
操作系统OS是触动了谁的蛋糕？当之无愧是目前世界上普及率最高的微软Windows系统。操作系统有壁垒或者门槛吗？我的回答是没有，产品和技术都不会成为壁垒和门槛，只能维持短暂的领先优势，微软的Windows到后面是技术领先吗？显然不是，是跑在它上面的应用让它成为了事实上的标准，而Sam正在做这件事情，GPTs和GPTs Store就是AI应用生态的探路石，AI Pin的Cosmos OS是他在构建AI系统OS上的探路石，甚至投资了操作系统OS的底层交互Induced AI，使用自动化RPA+AI的方式来交互OS，做足了准备。

🤠全局来看，微软发现Sam Altman悄悄的准备好了束缚自己两条腿的绳索，它回眸一瞥，发现Sam Altman正驾驶着坦克朝自己滚滚而来。

其他消息：
Openai认为Sam推出GPTs提出分成获利，与Openai的主体属性“非营利性组织”不符？
微软方面称：Sam被开除一分钟前才收到消息？
Sam的决策受到董事会牵制，背后与Meta小扎接触？
Sam在Dev Day前对董事会有所隐瞒？

💻下期交流AI产品的壁垒是什么？&Sam方向推测#ai#web3#openai#产品经理#程序员#互联网大厂#GPTS#离职
