---
title: "智谱ChatGLM4的Bug发现&与GPTs在Function Call上的差异"
date: "2024-01-16"
status: "published"
author: "Guotao Tao"
source_url: "https://mp.weixin.qq.com/s/pm5HaQFJe4Z1-fD3PiHR-Q"
cover_image: ""
id: "7145a73e-f8d8-4a22-b489-c2c2c3db7719"
slug: "智谱chatglm4的bug发现与gpts在function-call上的差异"
export_index: 24
---

# 智谱ChatGLM4的Bug发现&与GPTs在Function Call上的差异

> function call differences

ChatGLM4&GLMs中的Bug问题，关于Agent函数调用Function Call，与Openai的GPTs进行对比，探索其背后的架构原因。

1. **Bug复现**
2. **Function Call架构对比**

今天智谱ChatGLM4，可喜可贺，国内能力最全的模型，文本、视觉、代码，做的非常好，非常看好他的潜力。

一发布就迫不及待地去体验了下，总的来说挺好用的，体验很轻巧流畅，但还真发现了一个问题，关于Function Call调用插件函数的问题，一起来复现下：

# **1、Bug复现**

## **调试页面**

在GLMs配置页，左侧取消勾选掉【联网能力】和【AI绘画】两项能力，在右侧实时的进行调试，但在提交一些需要联网和绘画能力的prompt时，模型仍然调用了【联网能力】和【AI绘画】能力。

![](https://mmbiz.qpic.cn/mmbiz_jpg/Biatd5hKTdAYve3OzmTKqX6aSicREwBW3uuSWfehtnwfMeWoc9ZarbWicBl8sibrPj1Jmkbx3HekFY5wichlECrtFew/640?wx_fmt=jpeg&from=appmsg)

## **使用页面**

在GLMs正式使用页面，输入需要调用【联网能力】和【AI绘画】能力的prompt，模型仍然返回调用这两项能力的结果，尽管我配置时已经取消掉了勾选；

进入编辑GLMs的界面，会发现取消勾选掉的这两项能力，竟然又被自动的、重新选中了。

![](https://mmbiz.qpic.cn/mmbiz_jpg/Biatd5hKTdAYve3OzmTKqX6aSicREwBW3ucGw6TicvTGtJOh6BDg1ianSeubJIJADWdFlD12zm8S1Wzw1Y0eLE9kaA/640?wx_fmt=jpeg&from=appmsg)

# **2、Function Call架构原因**

**![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAYve3OzmTKqX6aSicREwBW3ubwPyticZseciaRodYgnrib9p5UqxFYLGCTwDFf1dWroarhozckMR0wsxw/640?wx_fmt=png&from=appmsg)**

- GLMs这里的Tools调用都是模型根据用户输入的prompt来进行Function Call的，我理解的是这次智谱的ChatGLM4和百度的文心一言4.0一样，将支持Function Call调用的tools工具库封装在模型内部，而不是像GPTs那样在模型外部。
- 这就是说只要你选了这个GLM4模型，你就已经拥有了【联网能力】和【AI绘画】能力，无关你配置GLMs中有没有勾选【联网能力】和【AI绘画】这两个复选框，当然既然如此，这里暴露出来的【联网能力】和【AI绘画】两个选型也没有意义，除非它将这两个能力和模型本身Function Call的tools工具库里链接起来，即用户在前端界面取消了勾选【联网能力】，那么后端模型处就从tools工具库里取消掉【联网能力】这个函数的选中状态。
- 下面所对比的GLMs和GPTs的Function Call函数调用架构中，GLMs会比GPTs多封装一层，把ChatGLM模型和函数工具库封装在一起，拿水泥牢牢地绑在一起，拿不走也加不进去，少了一些自由和灵活度。

## **GLMs的Function Call架构**

包装好的ChatGLM，提供给GLMs，tools工具库是固定的，就是智谱GLM提供的，即使你想让GLMs调用你自己的API工具函数，比如你自己的查询CRM的工具，但由于它是智谱官方封装好的，不支持用户在GLMs增加自己的API函数调用，除非你脱离GLMs直接来使用ChatGLM构建Agent框架应用。

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAYve3OzmTKqX6aSicREwBW3uLuG9xzRkh623D4VROfyxibBQCZlKCuK5b9f05Q8uTFFGhz5nXyoewKA/640?wx_fmt=png&from=appmsg)

## **GPTs的Function Call架构**

未封装ChatGPT,将ChatGPT模型本身和各种Function Call工具完全隔离开来，可以增加自己的tool工具到GPTs的Function Call工具库，就是GPTs的Actions功能配置。

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAYve3OzmTKqX6aSicREwBW3uzC3OJUWFsxpoaHenKkl3c6YeMtYOH6cIcxyM51B9pgowljv0fW9LQw/640?wx_fmt=png&from=appmsg)

下篇文章聊一聊Function Call调用函数的具体步骤拆解。
