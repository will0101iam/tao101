---
title: "OpenAI的新功能：将用户“人”作为LLM与GPTs的润滑剂"
date: "2024-01-30"
status: "published"
author: "Guotao Tao"
source_url: "https://mp.weixin.qq.com/s/6p8boQXLnouMHKwIpwTiVQ"
cover_image: ""
id: "9cf366f5-d0f3-4321-a7a2-98691c74f2f6"
slug: "openai的新功能将用户人作为llm与gpts的润滑剂"
export_index: 22
---

# OpenAI的新功能：将用户“人”作为LLM与GPTs的润滑剂

> humans as the lubricant for llms

最近工作有些许烦恼，老板实在是好糊弄，被水货产品一顿疯狂赞同吹捧。在拎得清的人看来是方向出错的产品，而他直接对未来充满了憧憬，固执己见不调整，听不进我和技术总的多次方向建议，只听得进去水货产品的赞同马屁，做那只被风吹起来猪头三的黄粱美梦。

md年后真得跑路了。

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAanOWguEbibUho28KzMABiaNCHfZnX2tSVd0Kfa0d0FKicEGFFdRW0oeHoK2KVeF34KJJ1h8ybucWTjw/640?wx_fmt=png&from=appmsg)

## **01**

## **OpenAI的新功能**

上周五Openai更新了一个功能，能够在普通对话的输入框内通过键入@来唤起所需的GPTs，将这次的prompt转给被@到的GPTs，让其来生成这次的回答结果。

## **02**

## **@唤起与GPTs的关系思考**

有人说这是AI chatbot之间的对话，实现了类似于群聊的多元化；有人说类似于AutoGen的Muilt Agent设定；大家说的都特好，但是我最近一段时间在专注于GPTs的需求设计和规划，越做下去越觉得没有意思。

扒开GPTs的外衣，发现里面有价值的唯有三个：Instructions指示、Knowledge知识、Actions函数调用，GPTs将这三者打包封装起来，做成了一个用来解决特定场景下的特定问题，一个增强版的Tool工具，一个聚合版的Function函数。

诚如这次Openai支持用户使用@来调用这个增强版的Tool工具，用户“人”充当了Function Call任务中的的Agent-bot，充当workflow中的一环，充当LLM与GPTs之间的润滑剂。

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAanOWguEbibUho28KzMABiaNCHfZnX2tSVd0Kfa0d0FKicEGFFdRW0oeHoK2KVeF34KJJ1h8ybucWTjw/640?wx_fmt=png&from=appmsg)

## **03**

## **Openai的产品化趋势**

这次Openai的@功能考虑到Agent框架在多线程、复杂任务下的不稳定，Openai大胆的让用户"人”来充当调度Agent，充当AutoGen中的Assistant role，充当X Agent中的外循环Plan Agent role。

最近也发现新增了存储历史对话、引用文本内容、类似Bard的方案选优等功能，这些也反映出Openai在进行产品化、交互优化的工作，而不是之前的技术边界决定产品边界，有什么新技术就立马上线产品的状态；

侧面也反映出GenAI的这轮技术在短期内不会有太多的变化和趋势起伏，短期内技术趋向平稳，产品会被着重来思考、设计、优化、应用、落地，到了技术冲积区，看产品会不会有新的落地机会，拿着锤子找钉子？or 对着钉子造锤子？

期待有能让人眼前一亮的AI产品，过去几个月属实有些审美疲劳了哈哈，没有看到有新意的产品。
