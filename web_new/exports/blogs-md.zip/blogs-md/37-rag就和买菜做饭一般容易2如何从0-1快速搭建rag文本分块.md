---
title: "RAG就和买菜做饭一般容易（2）：如何从0-1快速搭建RAG——文本分块"
date: "2023-12-03"
status: "published"
author: "Guotao Tao"
source_url: "https://mp.weixin.qq.com/s/saXBXpHonFNENCZKF9O0sQ"
cover_image: ""
id: "6a927aef-62c0-435c-a2e5-d61f85295846"
slug: "rag就和买菜做饭一般容易2如何从0-1快速搭建rag文本分块"
export_index: 37
---

# RAG就和买菜做饭一般容易（2）：如何从0-1快速搭建RAG——文本分块

> text chunking for rag

文本分块是将大块文本分解成更小的片段的过程，让大模型更好的细嚼慢咽。

在完成下一步嵌入向量化后，文本分块有助于优化我们从向量数据库返回的内容的相关性，返回设定好的几个块，例如top_k=6，即会返回6个相关性高的文本块给到LLM生成答案。

为什么要做文本分块，不分不好吗？不分不行吗？

不行，文本分块是为了方便向量检索时能准确匹配到高相关性的几个文本片段，提高大模型LLM以此生成答案的准确性。不分块，那么大模型需要面对的是整篇文档，不仅消耗toekn成本，受限于不同LLM的输入长度限制，而且吧一整个文档让LLM理解并分析再吐出答案，这个效率太差了，而且一整个文档LLM怎么知道重点在哪里？就好像你把一盆没切过的大白菜、没切的烤鸭端上了大模型的餐桌，你又让它怎么吃的又快又好呢，难以下咽。

讲讲几种常用的文本分块的方法：

1、CharacterTextSplitter分割：

`作为Langchain中默认的文本分块策略，CharacterTextSplitter`是一种直接的方法，它根据设定的字符数来直接切分文本。比如，如果设置为每1000个字符进行一次分割，那么它会不考虑文本的内在结构，直接每1000个字符切分一次，那它的chun_size=1000，意为每一个块的文本长度。

2、使用NLTK和spaCy分割：

NLTK和spaCy分割：基于NLP技术，能够理解文本结构，有效识别句子边界，特别是在处理含有复杂标点和缩写的文本时。

比如：

给定一段文本："Dr. Smith, who works at St. Mary's hospital, said: 'The patient's condition is stable. He will need more tests.' However, Mrs. Jones (the patient's mother) remains concerned."

- 普通句分割：可能会在"Dr." 和 "St."后错误地分割，因为它仅根据句号来判断。
- 使用NLTK或spaCy分割：这些工具会更智能地识别出"Dr. Smith"和"St. Mary's hospital"不是句子的结束，从而正确地只在引号闭合后和"However"前进行分割。

3、递归分割：

递归分块是根据文本的结构和内容来递归的。以一篇长文本为例，递归分块的步骤可能如下：

1. 初始分块：首先将整个文本分成几个大块，例如按章节分。
2. 细化分块：然后对每个大块再进行分块，比如将每个章节进一步分成几个小节。
3. 重复步骤：对每个更小的块继续执行类似的分块操作，直到达到所需的粒度，例如将每个小节细分到段落或句子。

![](https://mmbiz.qpic.cn/mmbiz_jpg/Biatd5hKTdAZ9HM4pJptE5zVkBv56Dr7HBfVoC11DvVmIdNy5x8QibVqvbuGZxibV0Qj8tELeic214zQKqVbL1z37g/640?wx_fmt=jpeg&from=appmsg)

上图是在文本分块策略选型时的一个样本，最后采用了递归分块的策略

最后具体实操中怎么来选取分块策略，还是要根据你的文本数据类型来定，长篇大论的论文和140字上限的微博内容的分析就会需要适配不同的分块策略，用固定的、不适合的分块策略会造成相关度下降。比如聊天记录消息类的就不建议来分块，最好让每条消息都作为一个单独的块，不揉杂在一起，打乱原有的语义。

文本分块对原内容是有压缩的，这分块的铡刀落在哪里都有可能，可能刚刚好不斩断连续的语义，也有可能恰恰落在连续的语义上，毁掉了原文的上下文意思，分块是不完美的，但也是RAG高效的必要条件。

正如文章开头所说的：文本分块就像庖丁解牛，让大模型更好的细嚼慢咽。

下期讲讲RAG中的嵌入是怎么一回事？向量是什么？文本、图像、音视频都能向量吗？力求通俗易懂的简单化。

![](https://mmbiz.qpic.cn/mmbiz_jpg/Biatd5hKTdAZ9HM4pJptE5zVkBv56Dr7HibCbBCofMuc6KWpa8nD0kbny0V2gTKicvpCxxfj9c83w37DO6Ffm26KQ/640?wx_fmt=webp&from=appmsg)
