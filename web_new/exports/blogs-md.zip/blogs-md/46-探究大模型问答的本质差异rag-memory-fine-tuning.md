---
title: "探究大模型问答的本质差异：RAG-Memory-Fine-Tuning"
date: "2023-10-30"
status: "published"
author: "Guotao Tao"
source_url: "https://mp.weixin.qq.com/s/e7B8P3yo3n8P2NjXM-XIEw"
cover_image: ""
id: "bf0b1a1d-8869-4525-ad95-9ee5ec6794c6"
slug: "探究大模型问答的本质差异rag-memory-fine-tuning"
export_index: 46
---

# 探究大模型问答的本质差异：RAG-Memory-Fine-Tuning

> rag vs memory vs fine-tuning

**RAG-Memory-Fine-Tuning**

🤖RAG这种方式的诞生，是因为LLM本身的训练，永远和及时发生的事情有时间差，最重要的是一些半公开、半透明的数据，LLM在训练的时候学习不到，而这些数据的持有者也恰恰有这样的需求；不仅如此，每一家LLM在训练的时候学习的语料都不太一样，有些东西未必会被学习，也就会造成你问它答不出来然后做梦幻觉的情况。

🐯那么RAG的本质是什么呢？

在我看来，RAG是一种搜索工具，LLM接入外部数据源，执行搜索的工具，同联网搜索以及其他Agent可调用的API工具函数一样，和上下文记忆、模型Fine-Tuning看起来差别很小，其实差别很大。

差别小在于，一个文档通过RAG、上下文记忆或者微调训练，对于用户的query，大部分情况下，LLM都能给出质量相差不大的结果。

差别大在于当用户的query不再是普通的询问，而是命令式的，比如总结这个文档、梳理若干个文档的逻辑关系，那么RAG由于其相对固定的top-k值，只能机械的从矢量库里捞固定数量的几个，这几个捞的准不准、能不能包含整个文档的chunks，一般都是捞不完全的，那么LLM总结的对象只是这个文档的top-k个chunks，而不是整个文档，这就和模型的上下文记忆或Fine-Tuning有着本质的区别。

👺Memory上下文记忆作为LLM能力的重要一节，目前也承载着对文本类文档的检索任务，长的上下文能支持更多的文本文档，在LLM的周期性的上下文记忆中、具体的某一节记忆中，本质上也是在这个范围内对LLM做学习训练，教会LLM读懂这部分的文档知识，比RAG更加深入了一步，更贴近LLM底层。但问题在于LLM存在中部记忆丧失的问题，目前也没有成熟的解决方案。

👿模型的Fine-Tuning训练区别于RAG的外挂，它是Native/Original的，知识记在脑子里，嵌在底层地基里，而RAG是知识记录在笔记本上，笔记本给你了你才学会上面的知识，上下文记忆则是你脑子里在某一个时刻只记住了一部分的笔记本内容，是记在脑子里的，不是像RAG那般在笔记本上搜索。那么在用户query的场景下，无论用户的query是询问还是命令式，LLM都能应对自如，不用再去翻笔记本了。

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAZhJmXsCU8ziclKhx2wVqiboKELN9O8tCtmEyVBsP3kgGFgrSlwINFNMNLOkuUzrV9FUibGXicVeFnfUA/640?wx_fmt=png)
