---
title: "转行AI-从Dify开始实践(4)-Agent详解"
date: "2024-10-17"
status: "published"
author: "Guotao Tao"
source_url: "https://mp.weixin.qq.com/s/3Bqt5UWG5m9545wDUE_WhA"
cover_image: ""
id: "3f257cf1-d7f4-41cd-aa80-c35a6b1154e5"
slug: "转行ai-从dify开始实践4-agent详解"
export_index: 13
---

# 转行AI-从Dify开始实践(4)-Agent详解

> understanding agents deeply

分享课件已更新

> https://c1mj4ytjg9.feishu.cn/docx/AsoHdjhxUo3pNDxBa31cLbr5nlh?from=from_copylink
> 
> 飞书文档：转行AI-从Dify开始实践

**1. Agent的定义和工作原理**

- Agent是一个自动化系统,能够识别用户意图并自动执行操作。

- 例如,当用户询问"去年哈佛录取了多少人"时,Agent会意识到需要联网搜索,调用Google搜索,获取相关链接,阅读内容,最后整合信息回答用户。

- Agent的基本工作流程包括:接收用户输入、意图识别、任务拆解、计划制定、工具选择、执行操作、整合结果、输出回答。

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAahDvIXuHtoNia225eI8Sr8ic4p6t4mdKIHzWujOXPHkD7zYZNEAXE3xiaJV4DjIW0AyPjTB4sWH5gRA/640?wx_fmt=png&from=appmsg)

**2. 搭建搜索引擎Agent示例**

- 使用Dify平台创建空白应用。

- 在工具库中选择并添加搜索引擎工具,如DuckDuckGo API(免费使用)。

- 设置Agent参数,包括模型选择(如GPT-4)和最大迭代次数(如5次)。

- 编写提示词指导Agent如何展示搜索结果和参考链接,例如将参考链接单独列在回答下方。

- 测试Agent,如询问"最近xx有什么新闻",观察Agent如何调用搜索工具并整合信息。

**3****. 搜索引擎工作原理**

- 搜索引擎会根据关键词返回多个相关网页。

- Agent会选择前几个(如前3个)搜索结果。

- 将这些网页的全部内容提取并输入到大语言模型中。

- 大模型根据这些"参考资料"和用户问题生成回答。

> 联网搜索详解
> 
> 吹水PM，公众号：NLP Agent
> 
> 解析AI大模型的联网搜索-2-种方案

**4. Agent的原理和架构**

- Agent需要工具储备、数据源和大语言模型作为基础。

- 大模型作为"项目经理",负责任务拆解、计划制定和工具调度。

- Agent会根据任务需求和工具描述选择合适的工具。例如,在解决数学方程时,会选择"数学老师"工具而非"计算器"工具。

- Agent的执行过程类似于项目开发流程:需求分解(任务拆解)、计划制定、工具调度(分配任务给开发人员)、执行、测试反馈。

**5. 多Agent协作**

- 微软提出的多Agent边缘协调方案,多个Agent在"群聊"中协作解决问题。

- 包括执行者、监督者等不同角色的Agent。

- 例如,在查询股票信息并给出投资建议时,执行者Agent负责获取股价信息,监督者Agent负责分析和提供建议,用户可以与多个Agent交互。

**6. Agent的应用类型**

- 狭义的Agent:设置好SOP流程执行任务,类似Workflow。适用于需要精确控制的场景。

- 广义的Agent:全自动化的智能助手,具有更高的自主性和灵活性。

- 应用案例:

- BySmart:一个智能购物助手,帮助用户在海外购物网站找到最适合的商品。

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAahDvIXuHtoNia225eI8Sr8icbav68CPOeyGHcicSc1tKEHNM9ibrCgt7Feg3QNhBr7klicyfSnk72CAag/640?wx_fmt=png&from=appmsg)

- AI搜索:根据用户需求整合多个信息源的内容。

- 化妆品推荐:基于社交媒体评论为用户推荐适合的护肤品。

**7. Agent框架**

- 清华大学提出的"X Agent"框架,包括外循环(快思)和内循环(慢想)。

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAahDvIXuHtoNia225eI8Sr8icefZpJicyoQwpB9veCibadgIoXjHpLm4MliciaRmFqzpogqHO18tQKyky0Q/640?wx_fmt=png&from=appmsg)

- 外循环负责任务拆解和总体规划,类似于人类的直觉思考。

- 内循环负责具体执行和深入分析,类似于人类的深度思考。

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAahDvIXuHtoNia225eI8Sr8icY5K5f0Kib0dxTOtcncIqdys45B6Mojfj9vnSuVeiar0Uib9jNUvTGCaBQ/640?wx_fmt=png&from=appmsg)

**8. 多模态多Agent系统:**

- 类似ChatGPT-4的工作原理,对问题进行深度理解和意图识别。

- 多个Agent协作,互相校验和改进答案。

- 过程包括:问题理解、意图识别、自我反思、多Agent交叉验证。

- 这种方法提高了输出的准确性和稳定性,类似于思维链(Chain of Thought)加上多轮编辑的过程。

**9. 相关工具和平台:**

### **-LangChain Tools**

> https://python.langchain.com/docs/integrations/tools

### **-Zapier**

> https://zapier.com/app/login?next=%2Feditor%2F210838496%2Fdraft%2F_GEN_1697126284477%2Fauth&redirect_cause=auth-required

### **-RapidAPI**

> https://rapidapi.com/collection/list-of-free-apis

### **-X Agent API**

> https://github.com/OpenBMB/XAgent/blob/main/ToolServer/README_ZH.md

wx：will0101iam
