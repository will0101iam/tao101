---
title: "转行AI-从Dify开始实践"
date: "2024-09-06"
status: "published"
author: "Guotao Tao"
source_url: "https://mp.weixin.qq.com/s/KSTSXLuQl5gC9a3tP3Pa1g"
cover_image: ""
id: "ded80da2-73c9-46c4-8477-164c5e5a30ed"
slug: "转行ai-从dify开始实践"
export_index: 16
---

# 转行AI-从Dify开始实践

> starting with dify

**01**

我的转行历程

我是去年从OA产品转到了AI产品经理，这过程中，学习AI技术，想象LLM在场景下的落地，将技术嫁接到产品设计上，更好的满足需求提高效率，转行过程中的三四个月时间很漫长，因为23年春天开始正好是AI技术大爆发的时候，每天都有各类消息渠道来轰炸信息流，如饥似渴的浸泡在其中，感受技术的日新月异，也感受到了LLM的魔法与吸引力。

02

转行AI-从Dify开始

那个时候没有一款很好的工具作为AI产品的demo搭建，现在有了：

Dify。

Dify从去年上市以来我就开始使用，非常优秀的一款产品，社区氛围非常好，也参与了workflow需求的调研，Dify能够通过低代码/无代码的方式，来构建AI产品背后的算法需求，RAG-Agent-Workflow-ASR/TTS，因此选择了Dify作为转行AI，从0-1学习llm的工具，来build一款AI产品的demo，解决某个场景上的问题。

在学习AI的过程中，有很多东西都需要自己去摸索和查询，有很多方向是错误的而陷入其中，我也阅读了很多优秀的文章来丰富我的知识与见解，而这些分享出来的知识都是深度的，因此我也有一个想法说，做几节完全好上手的分享课程（其实我很讨厌用课程这个词，有种坑人的倾向），帮助更多的人更快的更好的学习AI的知识。

03

分享课程

分享的魅力就是让分享者感受到助人的价值。

目前整理了5节分享，按照这个目录：

1、名词解释

2、Prompt

3、RAG

4、Agent

5、Workflow

目前更新到第二节prompt，争取抽时间在国庆节前全部更新完。

以下是分享链接，持续更新：

https://c1mj4ytjg9.feishu.cn/docx/AsoHdjhxUo3pNDxBa31cLbr5nlh?from=from_copylink

飞书文档

欢迎建联交流学习。

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAY1nmqlbibOxrsfxKdUWqhYfthxoceRib5otf4VKInACQNDKO7XiaE40tbwicDUgIxcBDIuBguXic45UiaQ/640?wx_fmt=png&from=appmsg)
