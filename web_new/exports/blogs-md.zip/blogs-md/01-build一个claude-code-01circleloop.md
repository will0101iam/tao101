---
title: "Build一个Claude Code-01：CircleLoop"
date: "2026-05-13"
status: "published"
author: "Guotao Tao"
source_url: "https://mp.weixin.qq.com/s/IBcSjuXRv0HPhQXhTE8Tcw"
cover_image: ""
id: "9555eb19-bec5-4afe-a545-8a594b78718c"
slug: "build一个claude-code-01circleloop"
export_index: 1
---

# Build一个Claude Code-01：CircleLoop

> ai agent loops vs linear execution

CircleLoop，这是个啥？

最近两篇文章我在学习和拆解 claude code，还有我对当下 ai 薄壳应用的和未来 ai 产品载体形式的看法，给我一种九九归一、浑然一体的感觉，从用户只知道用但做不了，到用户可以直接自己coding ，这是一个巨大的变化，下钻的如此厉害是没能想到的，当然薄壳应用还是有存活空间的，但跟“暴跌跳水”一样没差别的下钻是一个快速普及的趋势，而且很快，催化和驱动的因素很多。

既然用户都下沉到代码 build 层面了，那我在拆解 cc 之后，为什么不自己逆向 build 一个 cc 来更深入的实践一下呢，这会是一个更加深入的学习，我也不用其他可代替的开源组件模块，纯自己搭，make hands dirty，是有意义的。（其实是参考 cc 架构的一个 chatui/IDE）

现在的 circleloop 是一个啥进度，很惭愧，最近一周都没进度，在做其他的事情，时间一点不够用，但我其实很想把这块快些做完做好，不然我怕忘记里面的细节，所以我今天想干脆就写到公众号上，来更新进度，一是算是监督驱动自己吧，二是 build in public，能让更多的人看到和指出我的错误，也是一种学习。现在版本的进度还是上上周连续熬了4个晚上做出来的东西， 算是搭建好了基础的框架吧，如下图：

![](https://mmbiz.qpic.cn/mmbiz_png/fFwT6ibkWua9BvmlDlPWSykoy6aiaBibmhKVMh0wsiaV2XNK9cIHvpn2wNQjoCwKgwy6NPlpctphwUR0c12qvIVz0auhDTQdBesLyemicKZLOWRM/640?from=appmsg)

整个ui 风格是比较简单的，类似于 md 源码或者 README 的 那种风格，简单、粗糙、纯粹、原始，我喜欢这样的风格，只有黑白色系，加上边条框和 hover 状态，其他啥也没有，没啥原因为啥用这样的 ui，纯是自己喜欢哈哈。

整个产品的 PRD 我没写，整体我对产品的定义是按照我自己的需求来设计的，也并不是一个完全的 AI IDE，而是Chat and IDE，在前端做了故意的区分，在交互上避免了过分的割裂。cc、cursor、codex 要么是更晦涩难懂、使用门槛高的 CLI 终端，要么是典型的 IDE，虽然GUI 的形式使用门槛不高，但是对一个只想 chat 的用户，上来就要选文件夹 workspace、上来就是三列式卡片，还有那些多余的组件、按钮、功能都是心理负担，负向的东西，这个我没做过用户调研啊，不太科学，完全是我自己的用户感受，哎我就用的不爽，看着碍眼；然后如果是纯 chatui 的模式，想做一些 building 的时候，又觉得麻烦难用，看个文件都难受，各处都是限制，在云端沙箱里，非可视化，又想要完善的 coding 基础设施，就是上面所说的那些东西，简单的 chatui 又满足不了。

然后写这篇文章前就草草画了个图，理了一下框架吧，静态的，缺了动态的 agent runtime 图，后面边做边补吧。

![](https://mmbiz.qpic.cn/mmbiz_jpg/fFwT6ibkWuaicu3ibziargRqKsqCeZcHnnPu8iaEhjrxxVvqIsjLNVM0cicOkg5DxMYWFzuaLN5ia6gQfUTer1GNM2gVTfCPayUicg2hTZibfaCN5Ma4/640?from=appmsg)

如下展开：

1.基座层-确保 chat

## LLM 配置

这个是必不可少的，接入了 openroute、claude、chatgpt、ollama、openai-compatible 等常用的渠道，全局配置入口，前端显示 model_name 供用户切换，单 session 允许切换 model。

这里的所有 llm 去接入的时候，都会拿这个 llm 的 max_context参数，来给后面的 memory 管理来用，控制以后的上下文压缩。

## IM 模块

IM模块和市面上的其他 chat产品没什么差别，复制、重试、回滚这些常见的消息功能，我额外加了的一点是 branch 分支，因为我在使用 IDE 的时候，有时候看到 llm 的回答，是在讨论后续的实现计划或者说是偏流程类的，但是呢里面有一两处简单的问题我没理解，我想问但是我又怕打乱掉这个会话的上下文，影响 llm 的注意力，害怕影响后续的实现效果，所以我一般会复制这里面的问题，然后去浏览器的claude、grok 里面问。这个就比较麻烦，还要切换，然后东西也很分散，主体在 IDE 里面，东一块问在 claude、西一块问在 grok，然后脱离 ide、打开浏览器的过程也是一个分心的过程，视角切换，注意力转移，会一定程度上影响连贯的思考，所以我做了这么一个消息功能：branch。本质上就是把这个会话的所有消息都复制到另一个新的 session 里面去，然后在这个新的 session 里面问，随便问，像是一个草稿本吧，而且 circleloop 本来就不是一个严格的 ide、同时也是一个 chatui，那个词叫啥来着来着可盐可甜吧哈哈哈

这个 branch 的触发icon，我放在两个地方，一个场景是我刚刚说的，那么用户的出发点可能就在 llm 的这个回答上，用户的光标和注意力聚焦在这个回答上，消息是 hover 的状态，用户触发这个 branch 按钮是最快的，而且思考链路是最短的，像是“系统一”就触发了这个流程，用户的思维层级是在消息 IM 层；第二个场景我放在整个对话的右上角，这里的层级是 session 层，是对一个会话的 branch，出发的场景也不一样，比如我就在一个会话里聊，但是我突然想让他尝试一个困难的任务，可能有改坏代码的风险，rollback 未必能够确保安全，所以我就想复制这个 session 的内容，在新的 session 里面大胆实验试错，随便改代码，这里的场景出发点和层级就是会话级的，session 级 ，所以不同的触发场景和用户心智，我把 branch 按钮放埋在了两个地方。

下一个部分我想说的，是我觉得有一些麻烦复杂的 llm 的输出解析。

先从chatui 说起，就是 user 说一句，llm 回你一句，之前llm 没有thinking 能力的时候是很简单的，你问我答呗。

接着 llm有了 thinking 的能力，就要对用户的 thinking 推理的输出做兼容，在前端展示，那我解析的时候就加一个对 llm 的 reason 推理过程的字段就行了。

再然后出现了 deep research，llm 能够在 thinking reason 的时候给你多次的循环调用search 工具了，那你能不显示吗？不能啊，用户要看啊，要看你每一步的 query，每一步在干嘛，现在进度是啥，用户看着放心啊，确保你不是在乱烧 token，长时间的自动化任务要更多的展示内在，获得信任，那就得把每一轮的 llm 思考-调用 search 工具-反馈检查-是否下一轮的全部过程都得展示了，llm 返回的 thinking 字段里面就不仅仅是之前llm 自己纯思考了，还有使用各种工具的历史和路径。

最后，由于安全边界的设置，harness 的理念，一些高风险的工具或者命令，不能让 llm 自说自话就干了，必须要让用户 allow 审批，那么 thinking 阶段，还会弹出 ask user 的审批栏，需要用户审批，否则就中断进程，直到用户同意或者拒绝。

所以整个 thinking 里面塞了很多东西，里面的字段分割和聚合、解析和渲染、Orchestrator的状态机，执行进度……，什么都在里面了。

## SQLite-sessions

这部分很简单，就是把历史上的所有对话记录都存储到 sqlite 数据库里面，还有对左侧 session 的 pin、rename、delete 三个操作，其他也没有什么东西，这里的逻辑也很简单。

## 2.简单 agent loop

## While true loop

## Sandbox/Local workspace

## Bash、write、read 、ask等工具命令

## Prompt、层级claude.md规则

## Memory 管理

第二部分先不写了，下一篇整理下，今天距离写完第一部分已经过了三周了，三周没碰这个了，时间真是不够用。

欢迎添加 wx：will0101iam 交流分享，enjoy。
