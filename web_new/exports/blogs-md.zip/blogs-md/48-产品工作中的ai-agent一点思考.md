---
title: "产品工作中的AI-Agent一点思考"
date: "2023-10-18"
status: "published"
author: "Guotao Tao"
source_url: "https://mp.weixin.qq.com/s/x-5YvjTlNF61DFjAhDaW3Q"
cover_image: ""
id: "9e1a6f82-e04f-4ab2-a268-1935f0d24b6d"
slug: "产品工作中的ai-agent一点思考"
export_index: 48
---

# 产品工作中的AI-Agent一点思考

> agents in product work

- Agent的大方向：做通用层面的很有可能被Openai的更新一波带走，两条可行的路，一条做Agent框架，做中间层去提供服务，一条做垂直的Agent，针对某个领域行业，理解他的知识、工作流，做相对sop和chain的Agent。
- Agent的用户权限：含义是给用户多少的权限？基于以上的大方向，首先不考虑通用层面的交给用户的权限，一种是类似于Respell的模式，即PGC+UGC，平台给出几个设置好的Agent（Chain）流程，并鼓励用户用户自己搭建的Agent（Chain)流程；而另一种是主要面对B端，B端的熟悉整个工作流程的用户来搭建，让技术专家或者业务专家来搭建给整个企业提供服务，可视化的无代码/低代码的构建该企业专属的某个工作流程范式。
- 系统型超级应用的Agent：放在技术架构的底层，嵌在操作系统里，好比通过唤起Siri，发布指令来调用ios操作系统内Agent的以完成各种任务，猜测谷歌发布的新手机就是想干这事，把大模型压缩、裁剪、蒸馏为小模型嵌在手机本地，从权限最高的系统底层提供服务，国内vivo、小米也在干这事。

![](https://mmbiz.qpic.cn/mmbiz_jpg/Biatd5hKTdAYlAuxH6kUnvqFfNTS5RJ88Mqw78pgPOy7HDFRiacRBQNmuJs9XNbMVicfRyN1STNg7SyvNFibibicqF5Q/640?wx_fmt=jpeg)
