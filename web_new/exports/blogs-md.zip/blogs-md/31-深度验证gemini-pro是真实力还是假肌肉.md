---
title: "【深度验证】Gemini Pro：是真实力还是假肌肉？"
date: "2023-12-14"
status: "published"
author: "Guotao Tao"
source_url: "https://mp.weixin.qq.com/s/ehM-n-DUdwCR_Ea-lzR52g"
cover_image: ""
id: "5d4fb916-c6e6-40cc-85f0-71f372ad876c"
slug: "深度验证gemini-pro是真实力还是假肌肉"
export_index: 31
---

# 【深度验证】Gemini Pro：是真实力还是假肌肉？

> validating gemini pro

# **1、上下文窗口**

两个API：

GeminiPro只有该text字段有效。token限制为 32k。

Gemini Pro-Vision，您可以指定纯文本、文本和最多 16 张图像，或文本和 1 个视频。token限制为 16k。

# **2、格式限制**

- 图像：`image/png`、`image/jpeg`、`image/webp`、`image/heic`、`image/heif`、
- 视频：`video/mov`、`video/mpeg`、`video/mp4`、`video/mpg`、`video/avi`、`video/wmv`、`video/mpegps`、`video/flv`、
- 对图像分辨率没有限制。
- 最大视频长度：2 分钟。
- 大小限制：20MB

# **3、定价层**

**免费版本**支持每分钟最多60个请求，但输入输出数据将被用于改善谷歌的模型。

**付费计划**每千字符输入定价0.00025美元（约合人民币0.0018元），每千字符输出定价0.0005美元（约合人民币0.0036元），每张图像输入定价0.0025美元（约合人民币0.018元）。

以下为价格对比表，数据来源皆来自于官方API，token和字符数的换算比例来自于官方文档或token计数工具，人民币：美元汇率=7：1，字符计算方式为1汉字≈1字符。

| 模型名称/价格 | 输入（元/1000字符） | 输出（元/1000字符） |
| --- | --- | --- |
| Gemini pro | 0.0018 | 0.0036 |
| Chatgpt-3.5-turbo-1106 | 0.0078 | 0.0156 |
| Chatgpt-4-1106 | 0.0780 | 0.2340 |
| Claude2.0&Claude2.1 | 0.0630 | 0.1900 |
| 智谱ChatGLM-Turbo | 0.0028 | 0.0028 |

## **Gemini-Pro**

**输入0.0018元/1000字符；输出0.0036元/1000字符，图像输入0.018元/张**，视频呢？？？没公布

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAY9SB79l3uzbyCcAKgEBeia9SOyRy3deyDlLkLuRMRmJeStDiauCq8mL1UB304M2RDYuVq5ORb1rgRA/640?wx_fmt=png&from=appmsg)

## **智谱ChatGLM-Turbo**

一般情况下ChatGLM模型中token和字符数的换算比例约为1:1.8，即1000token=1800字符，0.005元 / 千tokens，即0.005元/1800字符，**输入输出等于0.0028元/1000字符**。

## **Chatgpt-4-1106**

token和字符数的换算比例约为1:0.9，即1000token=900字符，输入0.07元/千token，即0.07元/900字符，**输入等于0.078元/1000字符；输出等于0.234元/1000字符**。

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAY9SB79l3uzbyCcAKgEBeia9ibkXSyrLX7QcZvQ821I7EOhib78D1dl6GZHULgYPxkWn3ANN6xicet4Hw/640?wx_fmt=png&from=appmsg)

## **Chatgpt-3.5-turbo-1106**

token和字符数的换算比例约为1:0.9，**输入等于0.0078元/1000字符；输出等于0.0156元/1000字符**。

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAY9SB79l3uzbyCcAKgEBeia9GH3iasrAnVHmw8tYSwBbBQargjWIBtWzek8GFLianroB1Y4dFibjZBpYw/640?wx_fmt=png&from=appmsg)

## **Claude2.0&Claude2.1**

token和字符数的换算比例约为1:1.8，输入56元/一百万token，即0.056元/千token，**输入等于0.062元/1000字符；输出0.19元/1000字符。**

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAY9SB79l3uzbyCcAKgEBeia9Ly7IvTOoI5Q3chciaIJ6KGwZSuvt9ljDTecTyjPTsnI548mf6Es5ialA/640?wx_fmt=png&from=appmsg)

# **4、Gemini Pro Vision效果实测**

## **4.1、视频理解**

![](https://mmbiz.qpic.cn/mmbiz_jpg/Biatd5hKTdAY9SB79l3uzbyCcAKgEBeia9Bk62XvAUvGavBjENRpgZyoGNkicCaS5Yba6JkMiaNiaOJkdrRUjfmJ2uw/640?wx_fmt=jpeg&from=appmsg)

![](https://mmbiz.qpic.cn/mmbiz_jpg/Biatd5hKTdAY9SB79l3uzbyCcAKgEBeia9rictcsDJzZ5qokQyrepncKJlic00FDJjSLjCibticSeNs3ds0S3QibCEIsQ/640?wx_fmt=jpeg&from=appmsg)

![](https://mmbiz.qpic.cn/mmbiz_jpg/Biatd5hKTdAY9SB79l3uzbyCcAKgEBeia9O4IV6gdiaCk9xAAxzW1IQq8B9h6R288qFiclDWTtsibLAoWia3DTzJ3uAw/640?wx_fmt=jpeg&from=appmsg)

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAY9SB79l3uzbyCcAKgEBeia9CVmZM7KvpmibQlQzMOrb4SmFib756SEDPu13UtAHzYE8icAib3OzSTh0icQ/640?wx_fmt=png&from=appmsg)

## **4.2、图像理解**

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAY9SB79l3uzbyCcAKgEBeia9w4vg35qWCHoVK4bb8SrIsNLM78TA5Qm416DlicvugSRyPy2nvEmpVrw/640?wx_fmt=png&from=appmsg)

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAY9SB79l3uzbyCcAKgEBeia93dYg9n4TPGHH6G7FruIxZ3dUsmMs2qSic9ibX9THDFtM67k3pxfyV1Ig/640?wx_fmt=png&from=appmsg)

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAY9SB79l3uzbyCcAKgEBeia9z7iaVPFXcOTzva5fymZJiccDQy2dfCgkiaMvdRas17YScqsODdDJcX3nw/640?wx_fmt=png&from=appmsg)

**原因的猜想：**

- 识别图片中的数学题目，准确识别的但也不能够做对，说明语言文本的推理能力不佳，可能和模型训练时兼顾多模态，而分散了对语言文本训练的注意力，效果不及完全基于语言文本来训练的模型底座的ChatGPT。
- 视频理解能力的效果不佳，因为Gemini并不是从头到尾的理解整个视频，而是采用随机抽帧的方式，来解析抽到的几十几百张帧（图片），因此只是片面的回答关于视频的问题，会很片面。

测试下来，Gemini Pro的多模态能力非常一般，还不是很成熟，经常一本正经的胡说八道，甚至没有原先的Bard上的PaLM2理解图像效果好，Google着急发布感觉像是故意突出Google和多模态的影响力，和Openai造成差异化。
