---
title: "Claude式的RPA+AI是伪需求吗？"
date: "2024-10-22"
status: "published"
author: "Guotao Tao"
source_url: "https://mp.weixin.qq.com/s/eJiu5vSVihoVSyYHkgpnTQ"
cover_image: ""
id: "0c85cbe4-e298-4609-89ac-be0d04dc82a9"
slug: "claude式的rpaai是伪需求吗"
export_index: 12
---

# Claude式的RPA+AI是伪需求吗？

> rpa + ai: true or false demand?

## **01**

**Claude的新功能Computer Use**

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAacaqoRNbnWusoibFkFjN9SzGLwc1BLjIibFFjG4jbCIPKcZ1QaPRiavfN6qjfo4MVAgTssice1tWBSRA/640?wx_fmt=png&from=appmsg)

Claude 3.5 Sonnet周二更新了新的功能Computer Use，能够根据用户的指令，对计算机屏幕进行操控，完全类似于RPA+AI的模式。

整个workflow举一个实例：比如指令“请帮我在chrome浏览器中Google搜索麻省理工学院”，

1、首先他进行计划和任务拆解，拆成了两个步骤，第一步打开chrome浏览器，第二步Google搜索。

2、第一步它会使用vision功能，识别你的计算机桌面上有什么，发现一个chrome浏览器，然后它就双击打开了chrome浏览器，

3、然后在Google搜索框内输入麻省理工学院，至此执行完整个指令。

## **02**

**RPA+AI Agent失败的历史****尝试**

这则消息我一看到，联想起了两点：

一点是RPA厂商在AI上的尝试，他们的方向也是结合AI，达到这种Computer Use的功能，国内RPA厂商去年前仆后继的涌入这个赛道，影刀RPA，实在RPA的TARS-RPA-Agent**，**弘玑RPA的CTO跑出去创业做的澜码科技，这些去年在agent方向上很火的趋势，在今年已经听不到一点消息，消失在llm的信息流中。

另一点则是llm厂商在这个方向上的尝试，OpenAI CEO Sam投资了一家“RPA 3.0”的初创企业Induced AI，两位17、18岁的年轻人，Chatdev的发布者面壁智能发布了“APA”推出了ProAgent，智谱发布了CogAgent，腾讯推出了用于移动端的AppAgen，也有开源项目“seeact”。无一例外，以上都是去年的热媒，llm厂商也在这个时间点，抢注这个热点方向，但今年又集体噤声。Induced AI的产品今年上线了，5月份我用过，我给出的指令就是“用Google搜索麻省理工学院”，然后我在屏幕前呆呆的看着他一步步进行意图识别-写伪代码-执行交互，花了我三四分钟，速度太慢，效率太低，遂弃用了，上个月，我产品这边也需要用到一部分的RPA，我想起来这么个玩样，我再次上Induced AI看看，结果只有一个死掉的官网了，产品已经没有了，意思就是倒闭了，也在意料之中。

## **03**

**存在极大GAP的伪需求**

为什么我把这类RPA+AI的结合Computer Use看作是“伪需求”，不是一棍子打死所有这样的需求是伪需求，可能极小部分的场景需要这样的功能，但是，技术现实和要求的效果存在极大的Gap，有需求但是无法实现，之间是一条目前无法跨越的鸿沟，速度太慢，准确率太低。

在一个基准评估（OSWorld）中，Claude 目前得分为 14.9%。而人类水平通常为 70-75%，虽然已经远高于目前其他LLM跑出来最好的7.7%这个分数，但是还有非常遥远的距离要走。

Computer Use的难点也很多：

1. 在执行用户的任务中，用户的指令是什么离谱要求的，llm不知道用户输入的指令有多花，用户对Computer Use的技术边界的理解很模糊。
2. 指令中要使用什么样的工具，llm的tool库里面很有可能没有，即使有工具，比如爬虫，但是网页有反爬机制，自带的爬虫爬不下来。
3. 数据获取缺失：它该怎么去拿数据，现在方案是每一次都是用Vision进行识别获取数据，这就导致效率太低下了，速度会非常慢。
4. Vision的识别效果，目前Computer Use获得计算机屏幕的数据都是依靠Vision能力，但是Vision的输出有概率出错，前几天拿份纯文字文档让claude识别，里面错别字不少，
5. 意图识别：任务场景复杂性超乎想象，每个网页都不一样，有极多的概率性事件，比如网页上有两个词“设置”和“我的”，比如说我的指令是“更改我的收货地址”，好了，那llm该点开“设置”按钮呢，还是点开“我的”按钮呢？这让我点，我也不能肯定这个“收货地址”到底藏在哪里，让llm来判断更是不可能，要么两个都点开。
6. ……

## **04**

**证伪的核心问题**

最核心的一点是，Computer Use效率太慢准确率太低：

1. 简单任务，比如Google搜索，我执行只要2秒钟，你给我两三分钟，那我不如自己干，要你干什么？
2. 复杂任务，像上面提到的“收货地址”的两个按钮，我人都分不清，你怎么可能分得清呢，你也做不好，况且这个不算复杂，语义复杂而已。
3. 简单的重复性任务，嘿嘿又回到RPA的需求点上去了，电商公司、银行对账、黑灯工厂这种我不要llm带来的随机性，什么意图识别，我不要，我只要100%的准确性，那我编排RPA流程就好了，你llm在里面充当coplite我都嫌弃你给我降低准确率，给我惹祸。

总结一下Computer Use需求功能，简单任务我嫌弃，复杂任务你不行，简单重复性任务你不配。

让我想起了前段时间支付宝出的“支小宝”，出这种产品肯定不是产品团队的锅，估计是某leader要整点花活，跟下趋势，引发点舆论，让上边的人看到，自己kpi好写成绩优秀是吧。

这个方向目前看是需求不确定、不存在、不堪用，未来随着技术进步，或许很快，大家就能看到llm解决这些问题，一起期待。

《转行AI-从Dify开始》的分享课还差大家最后一节啦，剩下Workflow部分，争取下周全部做完更新到文档上去。

https://c1mj4ytjg9.feishu.cn/docx/AsoHdjhxUo3pNDxBa31cLbr5nlh?from=from_copylink

飞书文档：转行AI-从Dify开始实践

wx：will0101iam
