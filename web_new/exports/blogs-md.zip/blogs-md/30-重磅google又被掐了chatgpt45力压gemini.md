---
title: "【重磅】Google又被掐了：ChatGPT4.5力压Gemini"
date: "2023-12-14"
status: "published"
author: "Guotao Tao"
source_url: "https://mp.weixin.qq.com/s/DVTI94b1kIroDMDZE8UhIw"
cover_image: ""
id: "b389eb34-b811-4caa-b6af-d1c02e9b6917"
slug: "重磅google又被掐了chatgpt45力压gemini"
export_index: 30
---

# 【重磅】Google又被掐了：ChatGPT4.5力压Gemini

> the llm arms race

本文内容：

1. ChatGPT4.5规格、定价
2. ChatGPT4推出微调版本API
3. Google与Openai的刻意

![](https://mmbiz.qpic.cn/mmbiz_jpg/Biatd5hKTdAY9SB79l3uzbyCcAKgEBeia9kpWv2q87onkickicJOF4QpzhLjRicODh026k0X8yGmvWfAI6a2Kyicv7ibg/640?wx_fmt=other&from=appmsg)

GPT4.5提前泄露，多模态全方位力压Gemini，Google的多模态招牌的战术目的落空。

**1、ChatGPT4.5多版本泄露**

根据国外社交平台X及Reddit上泄露的消息，Openai的ChatGPT4.5版本即将推出，或许是2023年底的最后一枚重磅炸弹。

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAY9SB79l3uzbyCcAKgEBeia9icabCTFBlII3tQcNbtecIvy7jY8bBojEbNOic01SiazbJ8VJsjjIeJscQ/640?wx_fmt=png&from=appmsg)

从泄露的截图看出，这次的ChatGPT发布了3种型号：

**• GPT-4.5，输入为0.06美元/1000token，输出为0.18美元/1000token；**

**• GPT-4.5-64k，输入为0.12美元/1000token，输出为0.36美元/1000token；**

**• GPT-4.5-音频&语音，每分钟输入0.012美元，每分钟输出0.024美元；**

相比之前的 GPT-4 Turbo模型，GPT-4.5 的价格提高了整整6倍，GPT-4.5-64k的价格提高了12倍。

音频&语音模型一分钟输入+输出0.036美元似乎还好。一个3分钟电话客服的成本≈0.1美元，差不多7角钱煲一个3分钟时长的ChatGPT4.5的电话粥，还能接受。

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAY9SB79l3uzbyCcAKgEBeia9ziaPlYWowPrCT9CtRnmXZ1cl2iaLo0ofz8McfhjPbP9LSFicf0WXTHggg/640?wx_fmt=png&from=appmsg)

**2、GPT-4微调正式开放**

GPT-4微调接口的价格是0.09美元/1000token。使用时输入和输出分别是0.045和0.09美元每1000token，这个使用整整比GPT4-turbo贵了4倍还多！

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAY9SB79l3uzbyCcAKgEBeia9zSnscibDV2yKu9UZeciaqyIhe9m0EOpJ2ibQJslTjjhAia6wpCR5N0fUVw/640?wx_fmt=png&from=appmsg)

原因可能是随着模型训练参数的增加，训练难度会直线上升，边际成本也会增加，因此可能需要消耗更多的算力和调试模型。

**3、Google与Openai的刻意**

上一篇中我觉得Google着急发布Gemini，像是故意突出Google在多模态的影响力，达成用户心智中的认知和潜意识绑定，以此来和Openai拉开差异，这个意图已经被Google员工证实，就是为了抢在GPT4.5发布前匆忙发布，尽管能力并不免令人满意，尽管只是Pro版本，但效果是能感觉的到的，详情见另一篇Gemini pro的测评文章。
