---
title: "如何从 0-1 快速搭建 RAG（4）——语义检索&混合检索&重排序 Rerank"
date: "2023-12-12"
status: "published"
author: "Guotao Tao"
source_url: "https://mp.weixin.qq.com/s/PCUVU5LJZy3nNBXAScU-Rw"
cover_image: ""
id: "4843dc93-bb78-4b03-96b8-94f58e201e3f"
slug: "如何从-0-1-快速搭建-rag4语义检索混合检索重排序-rerank"
export_index: 33
---

# 如何从 0-1 快速搭建 RAG（4）——语义检索&混合检索&重排序 Rerank

> semantic search and reranking

本文2300字，详细解答RAG构建最关键一步：检索Retrieval，详解多种检索方式的优劣，给出选择生产应用的建议。

RAG（Retrieval Augmented Generation）：

这一 AI 领域目前最成熟应用最广泛的技术方案，每一个 Chatbot 都有一套 RAG 的管道。

终于迎来了搭建 RAG 管道的最后章节：检索 Retrieval。即将用户的 query 拿去向量数据库中做相似度匹配，捞出最相似的几个（top_k）文本块 chunks，最后喂给大模型 LLM 据此来生成回答。

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAYKQP3v4YDiavC1yUW5MGxoTGyWMZ5cYqXOz0sEicGFk8SVdSI83h0kK1jdIICCCKTVCFfqCBkl4pgQ/640?wx_fmt=png&from=appmsg)

语义检索、关键词检索和混合检索的流程对比

这一期讲最基础也是最容易实现的语义检索，你会发现单纯的语义检索存在许多的漏洞，导致召回率并不那么令人满意，因此推出了混合检索来强化检索的召回率和准确率。

1. # **什么是语义（矢量）检索？**

语义检索，字面意思即根据词句的内在意思来检索，能够发现词语和句子之间微妙的语义关系，例如“狼追小羊”和“豺狼追山羊”的语义关系就比“狼追小羊”和“我爱吃炸猪排”之间的语义关系更强

假设我的提问 query 是“狼和小羊”，那么 RAG 就会拿着 query 去向量数据库中寻找语义相似性高的块 chunks，每一个块会有一个相似度的分数，从高到低排序，假设“豺狼追山羊”的分数是 0.9（90 分），排名第 1，"我爱吃炸猪排"的相似度得分是 0.6（60 分），排名第 8，此时如果 RAG 设定的 top_k=6，score 分数=0.7，那意味着 RAG 管道会从得分 70 分以上的文本块中选取前 6 个捞出，喂给大模型，那么此时“豺狼追山羊”会被成功捞出召回，而“我爱吃炸猪排”因为得分低排名靠后，不能被召回，不能上岸。这就是完全基于语义的检索，召回的文本块会被 LLM 用来生成答案回答用户的 query。

1. # **语义检索的优劣？**

你可能会觉得：“哇！真棒哎！”，终于摆脱了那老掉牙的、冗余、精度低又机械命中的关键词检索，是的，没错，语义检索深入内容的语义本质，像人类一般去理解词与词、句与句之间的关系，使匹配检索更加的精准，富有情感和温度，而不是关键词检索那般冷酷和麻木。

- **理解相似的语义：**精确识别鸡蛋灌饼/煎饼果子/杂粮煎饼为一组，或是 Manner/M Stand/Peets/Tims 为一组。
- **支持多模态的检索：**支持第二篇所说的多模态的检索，比如你输入文本“加菲猫”，如果向量数据库中有它也能给你找出含有加菲猫的图片或视频。
- **提供多语言理解：**支持多种不同语言的向量匹配，比如“cat”和“猫”是一个意思，RAG 能够识别匹配。

然而，语义检索同时也存在着一些短板：

- **搜索产品名称或人名**：比如 iphone 15 pro 或者 Elon Musk
- **搜索一些特定名词**：比如 LLM 或者 text-embedding-ada-002

在这类检索任务中，

语义检索的嵌入向量化

这种转换依赖于上下文来理解词语的意义。但是，像“iphone 15 pro“”这样的短词，特别是在没有上下文的情况下，可能无法被有效地映射到一个具有丰富语义信息的向量上，因此 RAG 有极大概率会漏掉含有“iphone 15 pro”的文本块。而这一短板却恰恰是

关键词检索

的优势所在：

- **精准匹配**：精准匹配到仅出现一两次的文本内容。
- **匹配短小的字符**：关键词命中不论长短，都能够命中匹配，即使文本字符仅有”iphone 15 pro“这个字。

因此我们需要将语义检索和关键词检索混合起来使用，不放过任何一个召回，以求达到更好的检索效果。

1. # **为什么需要混合检索？**

理由如上文所述，语义检索有语义检索的优劣，关键词检索有关键词检索的优劣，那得了，我两个一起用不就好了，不仅更精确我都筛一遍，况且所带来的性能影响和成本影响微乎其微。

混合检索方案中，首先走一遍上面的语义检索流程，捞出前 6 个文本块（假设 top-k=6），接着使用关键词检索，拿着用户的 query 去命中文档库，为了增加命中率，可以使用模糊关键词匹配的模式，增加召回率，也同样得到 6 个相似度高的文本块，此时你已经获得了一共 12 个相似度都不低的文本块，你在想如果 12 个都扔给 LLM，那我的 token 消耗要爆炸了，我小钱包烧不起啊，你还是想就拿 6 个，那么你该拿哪 6 个文本块去给到大模型来生成内容呢？按照这 12 个文本块的相似度得分吗？可这是两种检索方式产生的得分，得分依据不同，很有可能明明你看着更相似的但得分却没有另一个一点不搭边的相似度得分高，我人眼一个个看谁更相似也太累了，我希望模型介入来解放我，那该怎么办呢？

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAYKQP3v4YDiavC1yUW5MGxoT9oQQYMicyIhnvJ7HJv0woMyQLgOEtW3DZ6EvYrIWUIBamp9kHVibia09g/640?wx_fmt=png&from=appmsg)

1. # **为什么需要重排序 Rerank？**

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAYKQP3v4YDiavC1yUW5MGxoTGJSNwk3uhS4h9zSSy6UdN6VlexFwCtMSPKUyvFbd0Y3m6kHRKrW6sg/640?wx_fmt=png&from=appmsg)

理由也诚然如上面所述，虽然混合搜索有效地结合了各种搜索技术以提高召回率，但我该怎么对通过语义检索和关键词检索出来的 12 个文本块来排序呢，怎么从中取出 6 个文本块呢？

因此有必要合并和规范化来自不同检索方式的查询结果，将 12 个文本块用统一的标准来再次排序，以便在喂给大型模型之前更好地进行比较、分析和处理。这就是重排序 Rerank 变得至关重要的地方。

通过重排序 Rerank 模型对 12 个文本块再次做了相似性的排序，这下你可以轻松地看到它们的得分情况，并选取前 6 个来给 LLM 生成答案，而且你不必担心挑选出来的文本块不相关，因为重排序 Rerank 模型会像大模型一样、像人类一样去深刻的理解文本块和 query 的相关性来评估。

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAYKQP3v4YDiavC1yUW5MGxoTq6KfAEtspGMG3Um1JWc9mjU93ibef3V0zjnLfax8G7P0q4RiccDKIzqQ/640?wx_fmt=png&from=appmsg)

重排序 Rerank 作为检索步骤之后的优化步骤，属于对检索效果的增强，提高召回的精确度，使 LLM 能得到更优质的文本块来生成答案，而且重排序模型非常轻巧，调用 API 接口即可，Cohere Rerank 为例，用户只需注册一个帐户，获取一个免费的 API 密钥，然后只需两行代码即可实现。此外，Cohere Rerank 支持多语言模型，允许同时对多种语言的文本查询进行排序。

1. # **微软 Azure AI search 实验研究依据**

微软在 9 月也进行了语义（矢量）检索、关键词检索和混合检索的效果比较，根据多轮不同数据集的测试结果，得到

混合检索+重排序 Rerank

的检索方式是最佳的，召回率和精确度都是最高的。

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAYKQP3v4YDiavC1yUW5MGxoTicJs6Exo8olpYwxN22uExDK78wgOfB9FdRoGTIgaREU23suBjZ43RKQ/640?wx_fmt=png&from=appmsg)

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAYKQP3v4YDiavC1yUW5MGxoTiaAIdRZ2wxNbKGj9fAk6iaHJRvZWmoDBJ83pe1ic4X0fsWU0FS0Tmv6XA/640?wx_fmt=png&from=appmsg)

关键词和向量检索从不同的角度处理搜索，从而产生互补的能力。向量检索在语义上将查询与具有相似含义的段落进行匹配。这是很强大的，因为嵌入对拼写错误、同义词和短语差异不太敏感，甚至可以在跨语言场景中工作。关键字搜索很有用，因为它会优先匹配可能在嵌入中被淡化的特定的重要单词。

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAYKQP3v4YDiavC1yUW5MGxoTYpDycaQY2pRwk6K8BBDw6UVlNKtEMiaF3aEZXZvDHBv1mbYbT8YjyUA/640?wx_fmt=png&from=appmsg)

1. # **结论**

我们通过多种检索方式的测试，发现混合检索始终能够发挥跨查询类型的两种检索方法的最佳性能，再加上重排序 Rerank 的增强，可以说是目前性价比最高的检索方案，能够满足绝大部分 RAG 的应用场景，也是我在方案调研上的最终选择。
