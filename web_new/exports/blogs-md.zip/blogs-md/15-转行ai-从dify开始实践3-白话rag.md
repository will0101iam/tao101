---
title: "转行AI-从Dify开始实践(3)-白话RAG"
date: "2024-09-11"
status: "published"
author: "Guotao Tao"
source_url: "https://mp.weixin.qq.com/s/a1J_65q9YQX3SwujMKt0KA"
cover_image: ""
id: "dfff9acc-37c2-48b6-a0e2-c7306804114b"
slug: "转行ai-从dify开始实践3-白话rag"
export_index: 15
---

# 转行AI-从Dify开始实践(3)-白话RAG

> rag explained simply

RAG技术深度解析：从理论到实践的全面指南

分享课件已更新

> https://c1mj4ytjg9.feishu.cn/docx/AsoHdjhxUo3pNDxBa31cLbr5nlh?from=from_copylink
> 
> 飞书文档：转行AI-从Dify开始实践

RAG技术概述

RAG (Retrieval-Augmented Generation) 是一种结合检索和生成的AI技术

解决了大模型知识时效性和专业领域知识缺失的问题

相比单纯增加上下文长度，RAG更高效、准确

RAG工作流程详解

a. 文档解析：将各种格式的文档转换为纯文本

b. 文本预处理：清理文本、去除无用符号

c. 文本分块：根据应用场景将文本切割成适当大小的块

d. 向量化（Embedding）：将文本块转换为向量

e. 向量检索：根据用户查询找到相关文本块

f. 结果生成：大模型结合检索结果和用户问题生成回答

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAYljVax5s5BLZnVI7ev9iaEALXnZQ3gpa0ERecU01ZB7G2UT23NYI5lkibMN8YRoA0TliafRC5giccBCw/640?wx_fmt=png&from=appmsg)

RAG关键技术点

文本分块策略：根据不同文本类型（如长文、微博）采用不同分块方法

Embedding模型选择：不同模型有不同维度，影响检索精度

混合检索：结合语义检索和关键词检索提高准确率

重排序（Rerank）：进一步优化检索结果

实践案例：房源匹配系统

使用真实房产数据演示RAG系统

展示了如何设置相似度阈值和Top-K参数

指出了实际应用中可能遇到的问题和局限性

RAG vs 其他技术

与大模型直接使用的区别：RAG像外挂，更灵活

与模型微调的区别：RAG无需改变模型本身，更易更新

RAG的挑战与未来

企业落地难点：数据清洗、多跳问题、路由问题等

准确率提升：从80%到95%需要大量额外工作

与其他技术的结合：如Agent技术的融合应用

学习建议

深入阅读历史文章，特别是讲者去年写的系列文章

探究大模型问答的本质差异：RAG-Memory-Fine-Tuning

RAG就和买菜做饭一般容易（1）：如何从0-1快速搭建一套RAG——文档解析

RAG就和买菜做饭一般容易（2）：如何从0-1快速搭建RAG——文本分块

RAG就和买菜做饭一般容易（3）：如何从0-1快速搭建一套RAG——嵌入向量化

如何从 0-1 快速搭建 RAG（4）——语义检索&混合检索&重排序 Rerank

使用工具如Dify进行实践

关注企业级应用场景，理解数据处理的重要性

个人见解

RAG技术虽然强大，但并非万能解决方案

企业应用中，数据处理往往比AI模型本身更具挑战性

鼓励读者动手实践，深入理解RAG的原理和应用

可添加wx：will0101iam进群交流
