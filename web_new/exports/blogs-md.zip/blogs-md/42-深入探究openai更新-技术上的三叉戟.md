---
title: "深入探究OpenAI更新-技术上的三叉戟"
date: "2023-11-10"
status: "published"
author: "Guotao Tao"
source_url: "https://mp.weixin.qq.com/s/C315NYsclHP_QMcBoMsUvw"
cover_image: ""
id: "9228445d-e7c5-497d-a10a-8082304a59d0"
slug: "深入探究openai更新-技术上的三叉戟"
export_index: 42
---

# 深入探究OpenAI更新-技术上的三叉戟

> openai's technical trident

这次OpenAI Dev Day更新，刨去其他媒体都会讲的128K上下文、价格降低等要点，这篇文章从技术层面来解析这次的OpenAI更新带来的哪些变化。

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAbFa3l3mrBzYW263ObWJMeNYiceqTTxkgDXyJuG1C3AZTicTQkyeiaibZ8ibagJt6icJNPGdS52icmaCTXXg/640?wx_fmt=png)

🤖**三叉戟：GPT4-Turbo、Assistant API、GPT Store，下文分别展开。**

👺GPT4-Turbo：跟老版本相比，在整个技术方案上有了变动

1. 是提出了线程（Thread）的概念，以往需要开发者自己处理上下文传给GPT，现在这活OpenAI帮你干了，线程存储着这个会话的所有历史上下文，简化了开发的工作量，但用户仍需为上下文的token而付费。
2. 是Message消息的范围，不再仅仅是文本内容，此次更新还包含了文件和图像，文件的格式支持与代码解释器一致，几乎包含了所有常见的格式，不仅仅是office三件套，支持直接在会话中针对文件问答，这和Poe、Claude如出一辙。
3. 则是Run运行，每一个用户的query发送给线程，线程开始进行处理，这都意味着一个Run的生成，类似于Agent框架中的任务理解和拆分，这个Run会包含一系列的"Steps"，它们可以看作是GPT解析用户的问题并生成正确答案的多个阶段。
4. 是上一步所述的Steps，是GPT解析用户的query并声称正确答案的多个阶段，类似于Agent中的任务分步执行，可以使用{tool_calls}来调用某个工具（例如，信息检索工具）以获取信息，尔后{message_creation}字段来令GPT生成一个新的消息Message作为对用户问题的回答。每个步骤Step的状态可能是"queued"（排队）、"in_progress"（进行中）、"completed"（已完成）或"failed"（失败）。

以上四点结合起来打个比方，就好像你坐在一家餐厅的餐桌旁，这个餐桌代表一个线程Thread。你在和一个名叫GPT的服务员交流，他会帮助你点餐和回答问题。
你向GPT说出你的点餐请求，这个请求就是一个Message消息。GPT接收到你的消息后，开始进行处理。这个开始处理过程就是一个运行run，运行代表了整个点餐和制作过程。
在运行的过程中，GPT会执行一系列的步骤Steps，比如烹饪汉堡、炸薯条、准备沙拉等。每个步骤都是为了完成你的点餐请求而进行的操作。
最后，当所有的步骤都完成时，GPT会将最终的结果{message_creation}返回给你，告诉你你的餐点已经准备好了。

👿Assistant API：RAG+代码解释器+Agent，干掉了类似于LangChain、Llama Index这样的中间件框架

1. OpenAI 会自动计算和存储 embedding，实现文档分块和搜索算法，不再需要自己折腾了。相当于是一个 SaaS 版的 LangChain。OpenAI的RAG检索分为两种方式，对于短文档，采取直接GPT阅读的方式，对于长文档，则执行分块、嵌入、检索的常规RAG方式，使用哪一种，完全取决于GPT的自我判断。
2. 代码解释器差别不大，在一个沙箱执行环境中编写并运行 Python 代码，并能生成图表，处理各种数据和格式的文件。Assistants 可以运行代码来解决复杂的代码和数学问题。
3. Agent的API函数调用，目前需要用户自己写API接口文档来接入目标API，相比之前的Function Call只能单次调用一个API函数，这次则支持多个API一起调用来完成任务。

🐯GPT Store：包含了OpenAI预设的、用户制作上传的GPTs

目前从性质上来看，主要分为两部分，一部分为普通的Prompts面具，扮演某个角色来对话执行任务，另一部分则是简陋粗糙的Agent，在我看来，之后仍然会以Agent为目的，这也是为什么大家惊呼GPTs要干掉许多的创业公司了，因为它允许大家的脑洞实现在GPTs上，自然语言就能生成一个建议的Agent 应用，打碎低端的创业公司的饭碗。Sam Altman 说道，“Over time, GPTs and Assistants are precursors to agents, are going to be do much much more. They will gradually be able to plan, and to perform more complex actions on your behalf.“（随着时间推移，GPTs 和助手将成为 Agent 的前身，将能做越来越多的事情。它们将逐渐能够规划，代表你完成更加复杂的行动。）也就是说，**Sam Altman 对 Agent 的期待很高，他认为现在的这些应用还不足以被称为 Agent**，任务规划这些核心问题还没解决，期待未来。By the way，我的Agent饭碗也快要被敲掉了。
