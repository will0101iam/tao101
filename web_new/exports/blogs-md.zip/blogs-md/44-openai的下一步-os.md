---
title: "OpenAI的下一步-OS"
date: "2023-11-06"
status: "published"
author: "Guotao Tao"
source_url: "https://mp.weixin.qq.com/s/6CnWBHzE4zlZmHzsnLmPpg"
cover_image: ""
id: "142fefb9-9853-4b97-a5c8-72052a8939f9"
slug: "openai的下一步-os"
export_index: 44
---

# OpenAI的下一步-OS

> openai's operating system

![](https://mmbiz.qpic.cn/mmbiz_jpg/Biatd5hKTdAZvYVgqR8Z6eEMadyqs1WiccVfvujGC2qcHQDqZFnR2tK9TlJh9PQFYlWgXP228kT59xib3EKKKoThA/640?wx_fmt=jpeg&from=appmsg)

今晚的openai dev day的发布会，全程掐表般的45分钟，紧凑快节奏输出非常多，分为以下三部分：

1、新的GPT4-Turbo模型，功能更强大、更便宜、支持token更长，128K相当于300页的文章，按照cl100k编码算，大约10万个汉字。
2、开放更多的API，包括视觉、图像创建（DALL·E 3） 和文本转语音（TTS），3新出了Assistants API，可以帮助开发者构建在自己的应用程序中构建Agent。
3、ChatGPT的更新，官宣AI Tools，发布用户可自定义的GPTs。

有了以上的铺垫，Agent和GPTs的最自由的前置条件就是拥有自己的**系统OS**，将Agent置于系统框架的底层，拥有控制终端的所有能力和权限，才算解锁了Agent的所有潜能，Agent Store也会有更加多的受众，普惠到每一个普通用户，就像移动互联网的各种Apple Store和安卓机的应用商城那样，筑自己的壁垒，打通Agent最后一公里的路径，实现闭环和完整的生态构建。
