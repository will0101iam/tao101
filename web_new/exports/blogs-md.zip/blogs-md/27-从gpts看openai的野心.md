---
title: "从GPTs看Openai的野心"
date: "2024-01-08"
status: "published"
author: "Guotao Tao"
source_url: "https://mp.weixin.qq.com/s/iBYOjVMrTdcHOTms9PtbNg"
cover_image: ""
id: "cfe7bdbf-ccd7-47bc-b6c8-e5e84a641f66"
slug: "从gpts看openai的野心"
export_index: 27
---

# 从GPTs看Openai的野心

> openai's true ambition

![](https://mmbiz.qpic.cn/mmbiz_png/Biatd5hKTdAbUicC8njhV9icGucDvWxyGA42nZZCnk7PDSAQ4wf1GC495U6YHuwAQLia9clc5eQKR9J1t2K7dQP5Jw/640?wx_fmt=png&from=appmsg)

1、GPTs即将推出GPTs市场

去年

11.6的Openai Dev Day上公布的GPTs功能，向用户提供了快速构建AI应用的能

力，将LangChain中的一部分LLMOps能力封装起来，做成了只需简单交互即可实现的SaaS版LangChain-GPTs。

毫无疑问，GPTs大大降低了AI应用的开发门槛，至少在那段严重依赖LangChain和Llama Index来开发的时间，GPTs的出现打破了部分B端AI创业者的美好向往，半道截胡，砸饭碗，但这些被抢夺生意的AI创业者或许做的并不是一门好生意，如此轻易就被截胡了。

# **2、GPTs带来的影响对AI创业有什么值得借鉴的地方呢？**

移动互联网早期，出来很多一开始很火的公司，比如安卓优化大师，当时有几亿用户，但现在谁还用安卓优化大师?没有。更简单的例子，当年有个在手机上做手电筒的公司也很火，今天iOS、安卓系统都自带(手电筒)了，现在和操作系统初期类似，大模型早期可能也顾不上很多边边角角的小功能，随时会给创业公司留下机会，但后面它腾出手来，马上就能把这些东西补上，这部分创业公司就没了，诚如这次GPTs对部分AI创业者的打击，Openai没时间做边边角角的功能，但是放出的GPTs先占了位置，我吃不到的你们也别想吃，不讲武德的砸饭碗。

# **3、GPTs里的隐藏野心Action-Agent？**

Openai这次放出的GPTs功能，里面有一个子能力预示着它的野心-Action，Action支持用户填入各种API来给GPTs来调用，本质上就是ChatGPT的Function Call，来调用各类接口实现AI-Agent，普通C端用户可能会接入一些Google Search、天气查询这类价值不大的场景API，那放在B端，是不是可以接入企业内部各系统，CRM、WMS、ERP等等呢，将企业的整个业务系统串联起来，解决现存在企业中的数据孤岛问题，将数据源打通。不仅提高了企业各业务系统间的数据流转，也方便了业务人员从数据库、业务系统中text2sql、取数、查询数据、输出表格。

一看这Action，简直是Openai这次释放GPTs里最深层次的功能，管你什么API数据源，我GPTs-Action给你通通接入，Action你用的好，GPTs搭建的好，你想用在业务上，Openai还给你提供Assistant API，让你无缝衔接进你的业务中，太贴心了Sam！但你GPTs接入的数据到哪里，最后还是回到了Openai，在哪个业务场景使用的好、带来的效率高，Openai也能立马反应，作为下一步方向的参考，毕竟孩子在别人家，谁也不能保证不会对孩子做什么手脚。

期待Openai这次释放GPTs Market会带来怎么样的运营策略。
